import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDb.instance.init();
  runApp(const MiliDeliceApp());
}

class MiliDeliceApp extends StatelessWidget {
  const MiliDeliceApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mili Délice Manager',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xff12315b),
        scaffoldBackgroundColor: const Color(0xfff4f7fb),
      ),
      home: const LoginGate(),
    );
  }
}

class AppDb {
  AppDb._();
  static final instance = AppDb._();
  Database? db;

  Future<void> init() async {
    final p = join(await getDatabasesPath(), 'mili_delice.db');
    db = await openDatabase(p, version: 1, onCreate: (d, v) async {
      await d.execute('CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,category TEXT,price REAL,cost REAL,active INTEGER)');
      await d.execute('CREATE TABLE ingredients(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,unit TEXT,qty REAL,unitPrice REAL,minQty REAL)');
      await d.execute('CREATE TABLE recipes(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,outputQty REAL,salePrice REAL)');
      await d.execute('CREATE TABLE recipe_items(id INTEGER PRIMARY KEY AUTOINCREMENT,recipeId INTEGER,ingredientId INTEGER,qty REAL)');
      await d.execute('CREATE TABLE production(id INTEGER PRIMARY KEY AUTOINCREMENT,recipeId INTEGER,qty REAL,lot TEXT,productionDate TEXT,dlc TEXT,totalCost REAL)');
      await d.execute('CREATE TABLE stock_moves(id INTEGER PRIMARY KEY AUTOINCREMENT,itemType TEXT,itemId INTEGER,qty REAL,moveType TEXT,unitCost REAL,date TEXT,note TEXT)');
      await d.execute('CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,product TEXT,qty REAL,unitPrice REAL,total REAL,payment TEXT,date TEXT)');
      await d.execute('CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,item TEXT,qty REAL,amount REAL,supplier TEXT,date TEXT)');
      await d.execute('CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,category TEXT,amount REAL,date TEXT)');
      await d.execute('CREATE TABLE investments(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,amount REAL,note TEXT,date TEXT)');
      await d.execute('CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,address TEXT,balance REAL)');
      await d.execute('CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,address TEXT,balance REAL)');
      await d.execute('CREATE TABLE employees(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,role TEXT,salary REAL,advance REAL)');
      await d.execute('CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,role TEXT,pin TEXT)');
      await d.insert('users', {'name':'Administrateur','role':'admin','pin':'1234'});
      await d.execute('CREATE TABLE cash(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT,amount REAL,reason TEXT,date TEXT)');
      await d.execute('CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,refType TEXT,refId INTEGER,amount REAL,method TEXT,date TEXT,note TEXT)');
      await d.execute('CREATE TABLE alerts(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT,message TEXT,date TEXT,seen INTEGER)');
      await d.execute('CREATE INDEX idx_stock_moves_date ON stock_moves(date)');
      await d.execute('CREATE INDEX idx_sales_date ON sales(date)');
      await d.execute('CREATE INDEX idx_production_date ON production(productionDate)');
    });
  }

  Future<List<Map<String,dynamic>>> q(String sql,[List<Object?> args=const []]) async => db!.rawQuery(sql,args);
  Future<int> insert(String table, Map<String,Object?> data) => db!.insert(table,data);
  Future<int> delete(String table,int id) => db!.delete(table,where:'id=?',whereArgs:[id]);
  Future<int> update(String table,Map<String,Object?> data,int id) => db!.update(table,data,where:'id=?',whereArgs:[id]);

  Future<void> createRecipe(String name,double output,double sale,List<Map<String,dynamic>> items) async {
    final id=await insert('recipes',{'name':name,'outputQty':output,'salePrice':sale});
    for(final x in items){
      await insert('recipe_items',{'recipeId':id,'ingredientId':x['ingredientId'],'qty':x['qty']});
    }
  }

  Future<double> recipeCost(int recipeId) async {
    final r=await q('SELECT SUM(ri.qty*i.unitPrice) c FROM recipe_items ri JOIN ingredients i ON i.id=ri.ingredientId WHERE ri.recipeId=?',[recipeId]);
    return (r.first['c'] as num?)?.toDouble() ?? 0;
  }

  Future<void> produce(int recipeId,double qty,String lot,String dlc) async {
    final rec=(await q('SELECT * FROM recipes WHERE id=?',[recipeId])).first;
    final items=await q('SELECT ri.*,i.name,i.unitPrice,i.qty stockQty FROM recipe_items ri JOIN ingredients i ON i.id=ri.ingredientId WHERE ri.recipeId=?',[recipeId]);
    final ratio=qty/(rec['outputQty'] as num).toDouble();
    double total=0;
    for(final x in items){
      final used=(x['qty'] as num).toDouble()*ratio;
      final stock=(x['stockQty'] as num).toDouble();
      if(stock<used) throw Exception('Stock insuffisant : ${x['name']}');
      total+=used*(x['unitPrice'] as num).toDouble();
      await update('ingredients',{'qty':stock-used},x['ingredientId'] as int);
      await insert('stock_moves',{'itemType':'ingredient','itemId':x['ingredientId'],'qty':used,'moveType':'production','unitCost':x['unitPrice'],'date':DateTime.now().toIso8601String(),'note':'Lot $lot'});
    }
    await insert('production',{'recipeId':recipeId,'qty':qty,'lot':lot,'productionDate':DateTime.now().toIso8601String(),'dlc':dlc,'totalCost':total});
  }
}

String money(num n)=>'${NumberFormat('#,##0','fr_FR').format(n)} F';
String dateNow()=>DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now());


class LoginGate extends StatefulWidget {
  const LoginGate({super.key});
  @override State<LoginGate> createState()=>_LoginGateState();
}
class _LoginGateState extends State<LoginGate>{
  final pin=TextEditingController(); bool busy=false;
  Future login() async {
    setState(()=>busy=true);
    final r=await AppDb.instance.q('SELECT * FROM users WHERE pin=?',[pin.text]);
    setState(()=>busy=false);
    if(!mounted)return;
    if(r.isNotEmpty) Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const HomePage()));
    else ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('PIN incorrect. PIN initial : 1234')));
  }
  @override Widget build(BuildContext c)=>Scaffold(
    body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(28),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
      Image.asset('assets/mili_delice_logo.png',width:140,height:140),
      const SizedBox(height:10),
      const Text('MILI DÉLICE',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
      const Text('Gestionnaire • Bamako'),
      const SizedBox(height:30),
      TextField(controller:pin,obscureText:true,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'PIN administrateur',border:OutlineInputBorder())),
      const SizedBox(height:14),
      SizedBox(width:double.infinity,child:ElevatedButton(onPressed:busy?null:login,child:Text(busy?'Connexion...':'Se connecter'))),
      const SizedBox(height:8),
      const Text('Changez le PIN initial 1234 après installation.',style:TextStyle(fontSize:12))
    ])));
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState()=>_HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index=0;
  final pages=const [
    DashboardPage(), ProductsPage(), RecipesPage(), StockPage(), ProductionPage(),
    SalesPage(), PurchasesPage(), ExpensesPage(), InvestmentsPage(), ReportsPage(), CustomersPage(), SuppliersPage(), EmployeesPage(), BackupPage(), SettingsPage()
  ];
  final labels=['Accueil','Produits','Recettes','Stock','Production','Ventes','Achats','Dépenses','Investissements','Rapports','Clients','Fournisseurs','Employés','Sauvegarde','Paramètres'];
  final icons=[Icons.dashboard,Icons.local_drink,Icons.science,Icons.inventory_2,Icons.factory,Icons.point_of_sale,Icons.shopping_cart,Icons.money_off,Icons.apartment,Icons.bar_chart,Icons.people,Icons.local_shipping,Icons.badge,Icons.backup,Icons.settings];

  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Row(children:[
          Image.asset('assets/mili_delice_logo.png',width:42,height:42),
          const SizedBox(width:8),
          const Text('Mili Délice Manager',style:TextStyle(fontWeight:FontWeight.bold))
        ]),
      ),
      drawer: Drawer(child:SafeArea(child:ListView(children:[
        Padding(padding:const EdgeInsets.all(16),child:Column(children:[
          Image.asset('assets/mili_delice_logo.png',width:110,height:110),
          const Text('MILI DÉLICE',style:TextStyle(fontWeight:FontWeight.bold,fontSize:20)),
          const Text('Bamako - Mali')
        ])),
        for(int i=0;i<labels.length;i++) ListTile(
          leading:Icon(icons[i]),title:Text(labels[i]),
          selected:index==i,onTap:(){setState(()=>index=i);Navigator.pop(context);}
        ),
      ]))),
      body:pages[index],
    );
  }
}

class DashboardPage extends StatefulWidget { const DashboardPage({super.key}); @override State<DashboardPage> createState()=>_DashboardPageState(); }
class _DashboardPageState extends State<DashboardPage>{
  Map<String,double> d={'sales':0,'expenses':0,'purchases':0,'invest':0};
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    final s=await AppDb.instance.q('SELECT COALESCE(SUM(total),0) v FROM sales');
    final e=await AppDb.instance.q('SELECT COALESCE(SUM(amount),0) v FROM expenses');
    final p=await AppDb.instance.q('SELECT COALESCE(SUM(amount),0) v FROM purchases');
    final i=await AppDb.instance.q('SELECT COALESCE(SUM(amount),0) v FROM investments');
    setState(()=>d={'sales':(s.first['v'] as num).toDouble(),'expenses':(e.first['v'] as num).toDouble(),'purchases':(p.first['v'] as num).toDouble(),'invest':(i.first['v'] as num).toDouble()});
  }
  @override Widget build(BuildContext c){
    final profit=d['sales']!-d['expenses']!-d['purchases']!;
    return RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(16),children:[
      const Text('Tableau de bord',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
      const SizedBox(height:12),
      GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),childAspectRatio:1.55,crossAxisSpacing:10,mainAxisSpacing:10,children:[
        Kpi('Chiffre d’affaires',money(d['sales']!)),Kpi('Achats',money(d['purchases']!)),
        Kpi('Dépenses',money(d['expenses']!)),Kpi('Bénéfice simplifié',money(profit)),
        Kpi('Investissements',money(d['invest']!)),
      ]),
      const SizedBox(height:20),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Text('Mili Délice — gestion de yaourt, stock, production, ventes et finances.',style:Theme.of(c).textTheme.bodyLarge)))
    ]));
  }
}
class Kpi extends StatelessWidget{final String title,value;const Kpi(this.title,this.value,{super.key});@override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Text(title,style:const TextStyle(fontSize:12)),const SizedBox(height:6),Text(value,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:19))])));}

class ProductsPage extends StatefulWidget{const ProductsPage({super.key});@override State<ProductsPage> createState()=>_ProductsPageState();}
class _ProductsPageState extends State<ProductsPage>{List<Map<String,dynamic>> rows=[];final n=TextEditingController(),p=TextEditingController(),co=TextEditingController();
Future load() async { final r=await AppDb.instance.q('SELECT * FROM products ORDER BY id DESC'); if(mounted)setState(()=>rows=r); }
@override void initState(){super.initState();load();}
Future add()async{if(n.text.isEmpty)return;await AppDb.instance.insert('products',{'name':n.text,'category':'Yaourt','price':double.tryParse(p.text)??0,'cost':double.tryParse(co.text)??0,'active':1});n.clear();p.clear();co.clear();load();}
@override Widget build(BuildContext c)=>GenericList(title:'Produits',rows:rows,columns:['Nom','Prix','Coût'],values:(x)=>[x['name'],money(x['price']),money(x['cost'])],form:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Nom du produit')),TextField(controller:p,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Prix de vente')),TextField(controller:co,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Coût de revient')),const SizedBox(height:8),ElevatedButton(onPressed:add,child:const Text('Ajouter'))]));}

class RecipesPage extends StatefulWidget{const RecipesPage({super.key});@override State<RecipesPage> createState()=>_RecipesPageState();}
class _RecipesPageState extends State<RecipesPage>{List<Map<String,dynamic>> rec=[];List<Map<String,dynamic>> ing=[];final name=TextEditingController(),out=TextEditingController(text:'100'),price=TextEditingController(text:'100');Map<int,double> qty={};
@override void initState(){super.initState();load();}
Future load()async{rec=await AppDb.instance.q('SELECT * FROM recipes ORDER BY id DESC');ing=await AppDb.instance.q('SELECT * FROM ingredients ORDER BY name');setState((){});}
Future add()async{final items=qty.entries.where((e)=>e.value>0).map((e)=>{'ingredientId':e.key,'qty':e.value}).toList();if(name.text.isEmpty||items.isEmpty)return;await AppDb.instance.createRecipe(name.text,double.parse(out.text),double.parse(price.text),items);name.clear();qty={};await load();}
@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
const Text('Recettes & coût de revient',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
TextField(controller:name,decoration:const InputDecoration(labelText:'Nom — ex. Yaourt 250 ml')),
Row(children:[Expanded(child:TextField(controller:out,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Unités/lot'))),const SizedBox(width:8),Expanded(child:TextField(controller:price,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Prix/unité')))]),
const SizedBox(height:12),const Text('Matières premières',style:TextStyle(fontWeight:FontWeight.bold)),
for(final x in ing) Row(children:[Expanded(child:Text('${x['name']} (${x['unit']})')),SizedBox(width:100,child:TextField(keyboardType:TextInputType.number,decoration:const InputDecoration(hintText:'Qté'),onChanged:(v)=>qty[x['id']]=double.tryParse(v)??0))]),
ElevatedButton(onPressed:add,child:const Text('Enregistrer la recette')),
const Divider(),...rec.map((r)=>FutureBuilder<double>(future:AppDb.instance.recipeCost(r['id']),builder:(c,s){final cost=s.data??0;final unit=cost/(r['outputQty'] as num);final margin=(r['salePrice'] as num)-unit;return Card(child:ListTile(title:Text(r['name']),subtitle:Text('Lot: ${r['outputQty']} • Coût lot: ${money(cost)} • Coût/unité: ${money(unit)} • Marge: ${money(margin)}')));}))
]);}

class StockPage extends StatefulWidget{const StockPage({super.key});@override State<StockPage> createState()=>_StockPageState();}
class _StockPageState extends State<StockPage>{List<Map<String,dynamic>> rows=[];final n=TextEditingController(),u=TextEditingController(text:'kg'),q=TextEditingController(),p=TextEditingController();
@override void initState(){super.initState();load();}Future load() async { final r=await AppDb.instance.q('SELECT * FROM ingredients ORDER BY name'); if(mounted)setState(()=>rows=r); }
Future add()async{await AppDb.instance.insert('ingredients',{'name':n.text,'unit':u.text,'qty':double.tryParse(q.text)??0,'unitPrice':double.tryParse(p.text)??0,'minQty':0});n.clear();q.clear();p.clear();load();}
@override Widget build(BuildContext c)=>GenericList(title:'Stock matières premières',rows:rows,columns:['Article','Qté','Prix'],values:(x)=>[x['name'],'${x['qty']} ${x['unit']}',money(x['unitPrice'])],form:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Article')),TextField(controller:u,decoration:const InputDecoration(labelText:'Unité')),TextField(controller:q,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Quantité')),TextField(controller:p,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Prix unitaire')),ElevatedButton(onPressed:add,child:const Text('Ajouter au stock'))]));}

class ProductionPage extends StatefulWidget{const ProductionPage({super.key});@override State<ProductionPage> createState()=>_ProductionPageState();}
class _ProductionPageState extends State<ProductionPage>{List<Map<String,dynamic>> rec=[];final qty=TextEditingController(text:'100'),lot=TextEditingController(),dlc=TextEditingController();
@override void initState(){super.initState();load();}Future load() async { final r=await AppDb.instance.q('SELECT * FROM recipes'); if(mounted)setState(()=>rec=r); }
Future produce(int id)async{try{await AppDb.instance.produce(id,double.parse(qty.text),lot.text,dlc.text);if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Production enregistrée et stock matières déduit.')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}
@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Production',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),TextField(controller:qty,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Quantité à produire')),TextField(controller:lot,decoration:const InputDecoration(labelText:'N° de lot')),TextField(controller:dlc,decoration:const InputDecoration(labelText:'DLC (AAAA-MM-JJ)')),const SizedBox(height:12),...rec.map((r)=>Card(child:ListTile(title:Text(r['name']),subtitle:Text('Coût standard: ${money((r['salePrice'] as num))} / unité — recette de ${r['outputQty']} unités'),trailing:ElevatedButton(onPressed:()=>produce(r['id']),child:const Text('Produire'))))) ]);}

class SalesPage extends StatefulWidget{const SalesPage({super.key});@override State<SalesPage> createState()=>_SalesPageState();}
class _SalesPageState extends State<SalesPage>{List<Map<String,dynamic>> rows=[];final prod=TextEditingController(),q=TextEditingController(),p=TextEditingController();String pay='Espèces';
@override void initState(){super.initState();load();}Future load() async { final r=await AppDb.instance.q('SELECT * FROM sales ORDER BY id DESC'); if(mounted)setState(()=>rows=r); }
Future add()async{final qty=double.tryParse(q.text)??0,price=double.tryParse(p.text)??0;await AppDb.instance.insert('sales',{'product':prod.text,'qty':qty,'unitPrice':price,'total':qty*price,'payment':pay,'date':dateNow()});prod.clear();q.clear();p.clear();load();}
Future receipt(Map<String,dynamic>x)async{final doc=pw.Document();final img=(await rootBundle.load('assets/mili_delice_logo.png')).buffer.asUint8List();doc.addPage(pw.Page(pageFormat:PdfPageFormat.a5,build:(ctx)=>pw.Column(children:[pw.Center(child:pw.Image(pw.MemoryImage(img),width:80)),pw.Text('MILI DÉLICE',style:pw.TextStyle(fontSize:20,fontWeight:pw.FontWeight.bold)),pw.Text('Yaourt • Bamako - Mali'),pw.SizedBox(height:12),pw.Text('Date : ${x['date']}'),pw.Divider(),pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[pw.Text(x['product']),pw.Text('${x['qty']} x ${money(x['unitPrice'])}')]),pw.Divider(),pw.Align(alignment:pw.Alignment.centerRight,child:pw.Text('TOTAL : ${money(x['total'])}',style:pw.TextStyle(fontWeight:pw.FontWeight.bold,fontSize:16))),pw.SizedBox(height:18),pw.Text('Merci pour votre confiance.')])));await Printing.layoutPdf(onLayout:(_)=>doc.save());}
@override Widget build(BuildContext c)=>GenericList(title:'Ventes',rows:rows,columns:['Produit','Qté','Total'],values:(x)=>[x['product'],x['qty'],money(x['total'])],form:Column(children:[TextField(controller:prod,decoration:const InputDecoration(labelText:'Produit')),TextField(controller:q,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Quantité')),TextField(controller:p,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Prix unitaire')),DropdownButtonFormField<String>(value:pay,items:['Espèces','Orange Money','Banque','Crédit'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>pay=v!),decoration:const InputDecoration(labelText:'Paiement')),ElevatedButton(onPressed:add,child:const Text('Enregistrer la vente')),const SizedBox(height:8),...rows.take(5).map((x)=>ListTile(title:Text(x['product']),subtitle:Text(money(x['total'])),trailing:IconButton(icon:const Icon(Icons.receipt_long),onPressed:()=>receipt(x))))]));}

class PurchasesPage extends StatefulWidget{const PurchasesPage({super.key});@override State<PurchasesPage> createState()=>_PurchasesPageState();}
class _PurchasesPageState extends State<PurchasesPage>{final item=TextEditingController(),q=TextEditingController(),a=TextEditingController(),s=TextEditingController();List<Map<String,dynamic>> rows=[];@override void initState(){super.initState();load();}Future load() async { final r=await AppDb.instance.q('SELECT * FROM purchases ORDER BY id DESC'); if(mounted)setState(()=>rows=r); }Future add()async{await AppDb.instance.insert('purchases',{'item':item.text,'qty':double.tryParse(q.text)??0,'amount':double.tryParse(a.text)??0,'supplier':s.text,'date':dateNow()});item.clear();q.clear();a.clear();s.clear();load();}@override Widget build(BuildContext c)=>GenericList(title:'Achats',rows:rows,columns:['Article','Qté','Montant'],values:(x)=>[x['item'],x['qty'],money(x['amount'])],form:Column(children:[TextField(controller:item,decoration:const InputDecoration(labelText:'Article')),TextField(controller:q,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Quantité')),TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Montant')),TextField(controller:s,decoration:const InputDecoration(labelText:'Fournisseur')),ElevatedButton(onPressed:add,child:const Text('Enregistrer'))]));}

class ExpensesPage extends StatefulWidget{const ExpensesPage({super.key});@override State<ExpensesPage> createState()=>_ExpensesPageState();}
class _ExpensesPageState extends State<ExpensesPage>{final n=TextEditingController(),a=TextEditingController();String cat='Transport';List<Map<String,dynamic>> rows=[];@override void initState(){super.initState();load();}Future load() async { final r=await AppDb.instance.q('SELECT * FROM expenses ORDER BY id DESC'); if(mounted)setState(()=>rows=r); }Future add()async{await AppDb.instance.insert('expenses',{'name':n.text,'category':cat,'amount':double.tryParse(a.text)??0,'date':dateNow()});n.clear();a.clear();load();}@override Widget build(BuildContext c)=>GenericList(title:'Dépenses',rows:rows,columns:['Libellé','Catégorie','Montant'],values:(x)=>[x['name'],x['category'],money(x['amount'])],form:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Libellé')),DropdownButtonFormField<String>(value:cat,items:['Transport','Eau/Électricité','Communication','Entretien','Salaires','Autre'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>cat=v!),decoration:const InputDecoration(labelText:'Catégorie')),TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Montant')),ElevatedButton(onPressed:add,child:const Text('Enregistrer'))]));}

class InvestmentsPage extends StatefulWidget{const InvestmentsPage({super.key});@override State<InvestmentsPage> createState()=>_InvestmentsPageState();}
class _InvestmentsPageState extends State<InvestmentsPage>{final n=TextEditingController(),a=TextEditingController(),note=TextEditingController();List<Map<String,dynamic>> rows=[];@override void initState(){super.initState();load();}Future load() async { final r=await AppDb.instance.q('SELECT * FROM investments ORDER BY id DESC'); if(mounted)setState(()=>rows=r); }Future add()async{await AppDb.instance.insert('investments',{'name':n.text,'amount':double.tryParse(a.text)??0,'note':note.text,'date':dateNow()});n.clear();a.clear();note.clear();load();}@override Widget build(BuildContext c)=>GenericList(title:'Investissements',rows:rows,columns:['Nom','Montant','Note'],values:(x)=>[x['name'],money(x['amount']),x['note']],form:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Investissement')),TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Montant')),TextField(controller:note,decoration:const InputDecoration(labelText:'Note')),ElevatedButton(onPressed:add,child:const Text('Enregistrer'))]));}

class ReportsPage extends StatelessWidget{const ReportsPage({super.key});Future<Map<String,double>> data()async{final s=await AppDb.instance.q('SELECT COALESCE(SUM(total),0) v FROM sales');final p=await AppDb.instance.q('SELECT COALESCE(SUM(amount),0) v FROM purchases');final e=await AppDb.instance.q('SELECT COALESCE(SUM(amount),0) v FROM expenses');final i=await AppDb.instance.q('SELECT COALESCE(SUM(amount),0) v FROM investments');return {'Ventes':(s.first['v'] as num).toDouble(),'Achats':(p.first['v'] as num).toDouble(),'Dépenses':(e.first['v'] as num).toDouble(),'Investissements':(i.first['v'] as num).toDouble()};}
@override Widget build(BuildContext c)=>FutureBuilder(future:data(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final d=s.data!;return ListView(padding:const EdgeInsets.all(16),children:[const Text('Rapports',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),...d.entries.map((e)=>Kpi(e.key,money(e.value))),Kpi('Résultat simplifié',money(d['Ventes']!-d['Achats']!-d['Dépenses']!))]);}}


class CustomersPage extends StatefulWidget{const CustomersPage({super.key});@override State<CustomersPage> createState()=>_CustomersPageState();}
class _CustomersPageState extends State<CustomersPage>{final n=TextEditingController(),p=TextEditingController(),a=TextEditingController();List<Map<String,dynamic>> rows=[];@override void initState(){super.initState();load();}Future load() async { final r=await AppDb.instance.q('SELECT * FROM customers ORDER BY id DESC'); if(mounted)setState(()=>rows=r); }Future add()async{await AppDb.instance.insert('customers',{'name':n.text,'phone':p.text,'address':a.text,'balance':0});n.clear();p.clear();a.clear();load();}@override Widget build(BuildContext c)=>GenericList(title:'Clients',rows:rows,columns:[],values:(x)=>[x['name'],x['phone'],x['address']],form:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Nom')),TextField(controller:p,decoration:const InputDecoration(labelText:'Téléphone')),TextField(controller:a,decoration:const InputDecoration(labelText:'Adresse')),ElevatedButton(onPressed:add,child:const Text('Ajouter le client'))]));}

class SuppliersPage extends StatefulWidget{const SuppliersPage({super.key});@override State<SuppliersPage> createState()=>_SuppliersPageState();}
class _SuppliersPageState extends State<SuppliersPage>{final n=TextEditingController(),p=TextEditingController(),a=TextEditingController();List<Map<String,dynamic>> rows=[];@override void initState(){super.initState();load();}Future load() async { final r=await AppDb.instance.q('SELECT * FROM suppliers ORDER BY id DESC'); if(mounted)setState(()=>rows=r); }Future add()async{await AppDb.instance.insert('suppliers',{'name':n.text,'phone':p.text,'address':a.text,'balance':0});n.clear();p.clear();a.clear();load();}@override Widget build(BuildContext c)=>GenericList(title:'Fournisseurs',rows:rows,columns:[],values:(x)=>[x['name'],x['phone'],x['address']],form:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Nom')),TextField(controller:p,decoration:const InputDecoration(labelText:'Téléphone')),TextField(controller:a,decoration:const InputDecoration(labelText:'Adresse')),ElevatedButton(onPressed:add,child:const Text('Ajouter le fournisseur'))]));}

class EmployeesPage extends StatefulWidget{const EmployeesPage({super.key});@override State<EmployeesPage> createState()=>_EmployeesPageState();}
class _EmployeesPageState extends State<EmployeesPage>{final n=TextEditingController(),r=TextEditingController(),s=TextEditingController();List<Map<String,dynamic>> rows=[];@override void initState(){super.initState();load();}Future load() async { final r=await AppDb.instance.q('SELECT * FROM employees ORDER BY id DESC'); if(mounted)setState(()=>rows=r); }Future add()async{await AppDb.instance.insert('employees',{'name':n.text,'role':r.text,'salary':double.tryParse(s.text)??0,'advance':0});n.clear();r.clear();s.clear();load();}@override Widget build(BuildContext c)=>GenericList(title:'Employés',rows:rows,columns:[],values:(x)=>[x['name'],x['role'],money(x['salary'])],form:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Nom')),TextField(controller:r,decoration:const InputDecoration(labelText:'Poste')),TextField(controller:s,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Salaire')),ElevatedButton(onPressed:add,child:const Text('Ajouter'))]));}

class BackupPage extends StatelessWidget{const BackupPage({super.key});
Future<String> backup()async{final dir=await getApplicationDocumentsDirectory();final dbPath=join(await getDatabasesPath(),'mili_delice.db');final out=join(dir,'mili_delice_backup_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.db');await File(dbPath).copy(out);return out;}
@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Sauvegarde & restauration',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:12),Card(child:ListTile(leading:const Icon(Icons.backup),title:const Text('Créer une sauvegarde locale'),subtitle:const Text('Copie de la base SQLite de l’application'),trailing:ElevatedButton(onPressed:()async{final p=await backup();if(c.mounted)ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('Sauvegarde créée : $p')));},child:const Text('Sauvegarder')))),const Padding(padding:EdgeInsets.all(8),child:Text('Pour une sauvegarde cloud, il faudra connecter Google Drive ou un autre service dans une prochaine étape.'))]);}

class SettingsPage extends StatefulWidget{const SettingsPage({super.key});@override State<SettingsPage> createState()=>_SettingsPageState();}
class _SettingsPageState extends State<SettingsPage>{final old=TextEditingController(),nw=TextEditingController();Future change()async{final r=await AppDb.instance.q('SELECT id FROM users WHERE pin=?',[old.text]);if(r.isEmpty){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Ancien PIN incorrect')));return;}await AppDb.instance.update('users',{'pin':nw.text},r.first['id'] as int);old.clear();nw.clear();if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('PIN modifié')));}
@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Paramètres',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:10),Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[const Text('Sécurité',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),TextField(controller:old,obscureText:true,decoration:const InputDecoration(labelText:'Ancien PIN')),TextField(controller:nw,obscureText:true,decoration:const InputDecoration(labelText:'Nouveau PIN')),ElevatedButton(onPressed:change,child:const Text('Changer le PIN'))]))),const Card(child:ListTile(title:Text('Mili Délice Manager'),subtitle:Text('Application de gestion — Bamako, Mali')))]);}

class GenericList extends StatelessWidget{final String title;final List<Map<String,dynamic>> rows;final List<String> columns;final List<dynamic> Function(Map<String,dynamic>) values;final Widget form;const GenericList({super.key,required this.title,required this.rows,required this.columns,required this.values,required this.form});
@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[Text(title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),Card(child:Padding(padding:const EdgeInsets.all(14),child:form)),const SizedBox(height:8),...rows.map((x){final v=values(x);return Card(child:ListTile(title:Text(v.isNotEmpty?'${v[0]}':'—'),subtitle:Text(v.skip(1).join(' • ')));})]);}
}
