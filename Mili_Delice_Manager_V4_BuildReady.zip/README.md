# Mili Délice Manager

Application Android de gestion de la production de yaourt de **Mili Délice**, Bamako — Mali.

## Fonctions
- Tableau de bord
- Produits et recettes
- Calcul du coût de revient
- Stock et production
- Ventes et reçus PDF avec logo
- Achats, dépenses et investissements
- Clients, fournisseurs et employés
- Sauvegarde locale
- Paramètres et changement du PIN

## Compilation Android depuis GitHub
Le dépôt contient `Mili_Delice_Manager_V4_Android.zip` et une action GitHub qui :
1. décompresse le projet ;
2. génère la structure Android Flutter ;
3. installe les dépendances ;
4. vérifie le code ;
5. construit l'APK release ;
6. publie l'APK comme artefact téléchargeable dans GitHub Actions.

PIN initial : **1234**.
