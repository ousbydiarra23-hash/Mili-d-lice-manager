# Mili Délice Manager V3
- Connexion par PIN
- Gestion clients, fournisseurs, employés
- Sauvegarde locale SQLite
- Paramètres avec changement du PIN
- Tables de caisse, paiements, alertes et index préparées
- Modules V2 conservés : recettes, coût de revient, stock, production, ventes, reçus PDF, achats, dépenses, investissements, rapports.
