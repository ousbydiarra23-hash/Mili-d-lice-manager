# Mili Délice Manager V4

Application Flutter Android de gestion de l'activité de yaourt de Mili Délice, Bamako.

## Fonctionnalités
- Connexion PIN (initial : 1234)
- Tableau de bord
- Produits
- Recettes et coût de revient
- Stock matières premières
- Production et déduction automatique du stock
- Lots et DLC
- Ventes et reçus PDF avec logo
- Achats
- Dépenses
- Investissements
- Rapports
- Clients
- Fournisseurs
- Employés
- Sauvegarde locale SQLite
- Paramètres et changement de PIN

## Compiler en APK
Prérequis : Flutter SDK + Android Studio + Android SDK.

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

APK : `build/app/outputs/flutter-apk/app-release.apk`
